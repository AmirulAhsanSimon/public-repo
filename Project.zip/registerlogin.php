<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
	<?php
include "indexu.php"; 
 ?>

</body>
</html>