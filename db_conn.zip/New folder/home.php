<?php
if(!isset($_SESSION['username'])){
	hedwer('location:login.php')
}

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="cpntainer">

<a href="logout.php"> LOGOUT</a>
<h1> Welcome <?php echo $_SESSION['username']; ?> </h1>
</div>
</body>
</html>
?>