<?php 
header('lication:login.php');
$db_server="localhost";
$db_user="root";
$db_pass=""
$db_name="Project"

$conn= mysquli_connect($db_server,$db_user,$db_pass,$db_name);
if(!$conn){
	die("Connection failed :"mysquli_conncetion_error());
 
}
mysqli_select_db($con, 'sessionpractical');
$name= $_POST['user'];
$pass= $_POST['password'];
$q= "select * form registration where name ='$name' && password='pass' "
$result= mysquli_query($con, $q);
$num = mysquli_num_row($result);
if($num==1){
	$_SESSION['username'] -$name;
	heder('location:home.php')


	
}
else{
	header('location.php')
}

 ?>