<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
    <form action="login.php" method="post">
      <h2>LOGIN</h2>
      <?php if(isset($_GET['error'])){ ?>
        <p class=""error"><?php echo $_GET['error'];?></p>

      <?php  }?>
      <label>User Name</label>
      <input type="text" name="uname" placeholder="Enter username"><br>

      <label>Password</label>
      <input type="password" name="password" placeholder="Enter password"><br>
      <button type="submit">Login</button><br><br>
      <div class="footer">
      <p>Not have an account?&nbsp;<br><a href="regis.php">Register</a></p>
    </div>
    </form>

  </body>
</html>
